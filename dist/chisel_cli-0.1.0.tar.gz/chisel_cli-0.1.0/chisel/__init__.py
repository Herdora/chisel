"""Chisel - A CLI tool for managing DigitalOcean GPU droplets for HIP kernel development."""

__version__ = "0.1.0"